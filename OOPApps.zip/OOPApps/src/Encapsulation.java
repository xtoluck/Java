class Encapsulation {
    private int age=10;
    private String name="OldName";
    public int getAge() {
        return age;
    }
    public void setAge(int newAge) {
        age = newAge;
    }

    public String  getName(){
        return name;
    }

    public void setName( String newName){
        name=newName;
    }
}


class ClassOfMethods {
    public static void main(String[] args) {
        Encapsulation obj = new Encapsulation(); //create an obj of the Class, Encapsulation
        obj.setAge(60); //using the obj of the class, Encapsulation to access the age value and setting it to a newAge. setAge() method supplying the argument i.e. the newAge value
        obj.setName("NewName"); //using the obj of the class, Encapsulation to access the name value and setting it to a newName. setName() method supplying the argument i.e. the newName value
        System.out.println();
        System.out.println("The newly set age returned by getAge() method is : "+obj.getAge());//getAge() returning the argument supplied- i.e. newAge value
        System.out.println();
        System.out.println("The newly set name returned by getName() method is : "+obj.getName());//getAge() returning the argument supplied- i.e. newAge value
    }

}


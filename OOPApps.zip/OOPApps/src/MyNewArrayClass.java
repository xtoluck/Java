import java.util.Scanner;

public class MyNewArrayClass {
   int sum;
    int i;
    public void arrayClsMtd() {
        System.out.println("Please enter Array Length: \n");
        Scanner sc = new Scanner(System.in);
        int userInput = sc.nextInt();

        int arrayVal[] = new int[userInput];

        for (int i = 0; i <= arrayVal.length; i++) {
//            for (int j = 0; j <= userInput; j++) {
//                System.out.println("The sum at index " + j + " of the length " + userInput + " is " + sum);
//                sum = sum + i++;
//            }
            sum = ((sum)+i++);
            System.out.println(sum/2);
//            sum = sum+ arrayVal[i];
//            int avg = sum / 2;
//            System.out.println("The average of length " + userInput + " is " + avg);

        }

       // System.out.println("The average of length " + userInput + " is " + arrayVal[i]);

    }


    public static void main(String[] args) {
        MyNewArrayClass obj = new MyNewArrayClass();
        obj.arrayClsMtd();

    }
}

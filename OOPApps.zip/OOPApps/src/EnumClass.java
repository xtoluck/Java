public class EnumClass {
}

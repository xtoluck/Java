import java.util.Scanner;

//Enum Class
public class ArrayClass {
    public String userInput(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Please enter array length");
       int arrayLength= sc.nextInt();

        int [] avg = new int[arrayLength];

        int result = 0;
        double [] average = new double[arrayLength];

        for (int i = 0; i <= avg.length; i++){
            result += i;
        }
        return String.valueOf(result/2);
    }

}

class MyClassMtd extends ArrayClass{
    public static void main(String[] args) {
        ArrayClass obj= new ArrayClass();

        System.out.println("The average of " +obj.userInput());
    }
}
//Interface Class
interface Animals {
    public void animalSound();//Interface method (does not have a body!)
    public void sleep();//Interface method (does not have a body!)
}
class Pig1 implements Animals{
    public void animalSound(){
        System.out.println("The pig says: wee wee");
    }
    public void sleep(){
        System.out.println("Animals sleep");
    }
}
class MyMainClass1{
    public static void main(String[] args) {
        System.out.println();
        Pig1 obj= new Pig1();
        obj.animalSound();
        obj.sleep();
    }
}
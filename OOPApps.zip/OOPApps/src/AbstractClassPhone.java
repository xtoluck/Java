//ABSTRACT CLASS AND ABSTRACT METHODS

class Phone {
    public static void main(String[] args) {
        HameshPhone phoneObj = new LuckyPhone();//This means phoneObj is a type of HameshPhone but it is an object of LuckyPhone
        phoneObj.call();
        phoneObj.move();
        phoneObj.dance();
        phoneObj.cook();
    }
}
abstract class HameshPhone {
    void call() {
        System.out.println("calling...");
    }

    public abstract void move();

    public abstract void dance();

    public abstract void cook();
}

abstract class RameshPhone extends HameshPhone {
    public void move() {
        System.out.println("moving...");
    }
}
class LuckyPhone extends RameshPhone{
    public void dance(){
        System.out.println("dancing...");
    }

    public void cook(){
        System.out.println("cooking...");
    }
}
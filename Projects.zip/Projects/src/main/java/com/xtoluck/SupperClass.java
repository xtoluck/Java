package com.xtoluck;

class SupperClass extends Object{
    public SupperClass(){//Constructor SupperClass
        System.out.println("In Superclass...");
    }

    public SupperClass( int a){
        System.out.println("In Superclass Parameterized Constructor...");
    }
}

class SubClass extends SupperClass {
    public SubClass() {//Constructor of Subclass
        System.out.println("In subclass...");
    }

    public SubClass(int a){//Parameterized Constructor
        //super(a);// This is a call to Superclass Parameterized Constructor

        this();//this() executes the contructor(s) of same class. There is a default super() which excecutes   lines 4 and 5, the superclass constructor
        System.out.println("In Parameterized Constructor of the subclass");
    }
}

class RunCode {

    public static void main(String[] args) {
        SubClass obj = new SubClass(4);
    }
}
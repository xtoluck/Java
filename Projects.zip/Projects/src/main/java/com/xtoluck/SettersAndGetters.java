package com.xtoluck;

public class SettersAndGetters {
    private String name;
    private int age;

    public SettersAndGetters(){//contructor
        System.out.println("In constructor");
    }
    public void print(){
        System.out.println(name+" : "+age);
    }
    public String getName(){
        return  name;
    }

    public void setName( String n){
        name=n;
    }

    public  int getAge(){
        return age;
    }
    public  void setAge(int  a){
        age=a;
    }
}

class Caller{
    public static void main(String[] args) {
SettersAndGetters obj=new SettersAndGetters();
obj.setAge(30);
obj.setName("Lucky");
obj.print();
    }
}
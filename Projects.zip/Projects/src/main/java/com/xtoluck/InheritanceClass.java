package com.xtoluck;

public class InheritanceClass {
    public static void main(String[] args) {
        AdvCalculator obj = new AdvCalculator();
        int r1 = obj.add(3, 9);
        int r2 = obj.sub(9, 2);
        int multiply = obj.multiply(5, 6);
        int divide=obj.div(90,4);
        System.out.println("Addition: " + r1 + "  Subtraction: " + r2+" Multiplication: "+multiply+"  Division: "+divide);

    }
}

class Calculator {
    public int add(int n1, int n2) {
        return n1 + n2;
    }

    public int sub(int n1, int n2) {
        return n1 - n2;
    }

}

class AdvCalculator extends Calculator {
    public int multiply(int a, int b) {
        return a * b;
    }

    public int div(int a, int b) {
        return a / b;
    }
}
import java.util.Scanner;
import java.util.concurrent.Callable;


// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Converters {
    void Converters() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Please enter Temperature value in Fahrenheit: ");
        double tempFahrenheit = sc.nextDouble();
        //  (32°F − 32) × 5/9 = 0°C  Formular
        double celsius = (tempFahrenheit - 32) * 5 / 9;
        System.out.println("The temperature in Celsius is: " + celsius + "°C");
    }

    void inchesToMetersConverter() {
        //formular : length/39.37
        System.out.println("Please enter the length in inches:");
        Scanner sc = new Scanner(System.in);
        double inches = sc.nextDouble();
        double length = inches / 39.37;
        System.out.println(inches + "inches is : " + length + "mtr");

    }

    void sumOfDigitsBtwZeroAnd1K() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Please enter numbers between 0 and 1000");
        int number = sc.nextInt();

        int firstDigit = number % 10;
        int remainingNumber = number / 10;
        System.out.println("FirstDigit: " + firstDigit);

        int secondDigit = remainingNumber % 10;
        remainingNumber = remainingNumber / 10;
        System.out.println("Remaining 1" + remainingNumber);

        int thirdDigit = remainingNumber % 10;
        remainingNumber = remainingNumber / 10;
        System.out.println("ThirdDigit: " + thirdDigit);

        int fourthDigit = remainingNumber % 10;
        System.out.println("FourthDigit : " + fourthDigit);

        int sum = firstDigit + secondDigit + thirdDigit + fourthDigit;
        System.out.println("The sum of " + number + " Digits is " + sum);

    }

    void minutesToDaysConverter() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Please enter the minutes: ");
        int minutes = sc.nextInt();

        int minsInYr = 60 * 24 * 365;

        long yr = minutes / minsInYr;
        long day = (minutes / 60 / 24) % 365;

//        int days = (minutes) / (1440 * 24);
        System.out.println(minutes + " minutes is approximately " + yr + " years " + day + " days");

    }


    void currentTimeInGMT() {
        System.out.println("Input the time zone offset to GMT");
        Scanner sc = new Scanner(System.in);
        long timeZoneChange = sc.nextInt();
        long totalMilliseconds = System.currentTimeMillis();
        long totalSeconds = totalMilliseconds / 1000;
        long currentSeconds = totalSeconds % 60;
        long totalMinutes = totalSeconds / 60;
        long currentMinutes = totalMinutes % 60;
        long totalHour = totalMinutes / 60;
        long currentHour = ((totalHour + timeZoneChange) % 24);
        System.out.println("The current time in Nigeria GMT is: " + (currentHour - 3) + " :" + currentMinutes + " :" + currentSeconds + " :" + " GMT");
    }


    void sixDigitsNumbers() {
        //Java program to break an integer into a sequence of digits.
        System.out.println("Input non-negative 6 Digits numbers");
        Scanner sc = new Scanner(System.in);
        int userInput = sc.nextInt();
        int num1 = userInput / 100000 % 10;
        int num2 = userInput / 10000 % 10;
        int num3 = userInput / 1000 % 10;
        int num4 = userInput / 100 % 10;
        int num5 = userInput / 10 % 10;
        int num6 = userInput % 10;

        System.out.println(num1 + " " + num2 + " " + num3 + " " + num4 + " " + num5 + " " + num6);

    }

    public class Hex_to_DecimalConversion {
        public static int hex_to_DecimalConversion(String s) {
            Scanner sc = new Scanner(System.in);
            String digits = "0123456789ABCDEF";

            s = s.toUpperCase();
            int val = 0;
            for (int i = 0; i < s.length(); i++) {
                char c = s.charAt(i);
                int d = digits.indexOf(c);
                val = 16 * val + d;
            }
            return val;
        }


    }

    //class CompareTwoNumbers {
    void CompareTwoNumbers() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter first number ");
        int firstNum = sc.nextInt();

        System.out.println("Enter second number ");
        int secondNum = sc.nextInt();

        if (firstNum == secondNum) {
//                System.out.println("Both Values are equal!");
//            } else if (firstNum<secondNum) {
//                System.out.println("First Number is less than Second Number!");
//            } else  {
//                System.out.println("Second number is greater than first number!");
//            }

            System.out.printf("%d == %d\n", firstNum, secondNum);
        } else if (firstNum < secondNum) {
            System.out.printf("%d < %d\n", firstNum, secondNum);
        } else if (firstNum != secondNum) {
            System.out.printf("%d != %d", firstNum, secondNum);
        } else if (firstNum <= secondNum) {
            System.out.printf("%d <= %d", firstNum, secondNum);
        } else if (firstNum == secondNum) {
            System.out.printf("%d == d%", firstNum, secondNum);
        } else if (secondNum < firstNum) {
            System.out.printf("%d < d%", secondNum, firstNum);
        } else if (secondNum <= firstNum) {
            System.out.printf("%d <=d%", secondNum, firstNum);
        } else System.out.printf("oops! wrong value entered.");
    }

    public static void main(String[] args) {
   /*     Converters convert=new Converters();
        convert.Converters();

        Converters convertIncToMeter = new Converters();
        convertIncToMeter.inchesToMetersConverter();

        Converters sumOfDigitssBtwZeroAnd1KObj = new Converters();
        sumOfDigitssBtwZeroAnd1KObj.sumOfDigtsBtwZeroAnd1K();

        Converters minutesToDaysObj = new Converters();
        minutesToDaysObj.minutesToDaysConverter();


        Converters currentTimeInGMTObj = new Converters();
        currentTimeInGMTObj.currentTimeInGMT();


        Converters sixDigitsNumbersObj = new Converters();
        sixDigitsNumbersObj.sixDigitsNumbers();
    */

        /*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        String hexdec_num;
        int dec_num;

        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a Hexadecimal Number ");
        hexdec_num=sc.nextLine();

        dec_num=   Hex_to_DecimalConversion.hex_to_DecimalConversion(hexdec_num);
        System.out.println("Equivalent Decimal Number is "+dec_num);
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        */

        Converters CompareTwoNumbersObj = new Converters();
        CompareTwoNumbersObj.CompareTwoNumbers();

    }
}
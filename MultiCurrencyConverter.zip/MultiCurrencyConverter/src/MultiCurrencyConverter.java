import java.util.Scanner;

public class MultiCurrencyConverter {
    String input;
    public static void main(String[] args) {


        System.out.println("Please Select the currency to convert:");


        try{

        }
        catch (Exception e) {

        }


        System.out.println("1: Naira to Dollar");
        System.out.println("2: Naira to Euro");
        System.out.println("3: Naira to Pounds");
        System.out.println("4: Euro to Naira");
        System.out.println("5: Pounds to Naira");
        System.out.println("6: Dollar to Pounds");
        System.out.println("7: Dollar to Euro");
        System.out.println("8: Pounds To Dollar");
        System.out.println("9: Pounds To Euro");
        System.out.println("10: Euro To Pounds");
        System.out.println("11: Euro To Dollar");

        Scanner scChoice = new Scanner(System.in);
        int choice = scChoice.nextInt();

        switch (choice) {
            case 1:
                nairaToDollar();
                break;
            case 2:
                nairaToEuro();
                break;
            case 3:
                nairaToPounds();
                break;
            case 4:
                euroToNaira();
                break;
            case 5:
                poundsToNaira();
                break;
            case 6:
                dollarToPounds();
                break;
            case 7:
                dollarToEuro();
                break;
            case 8:
                poundsToDollar();
                break;
            case 9:
                poundsToEuro();
                break;
            case 10:
                euroToPounds();
                break;
            case 11:
                euroToDollar();
                break;
            default:
                System.out.println("oops! Invalid entry. Please retry.");

                System.out.println("Do you want to retry? \n1: Yes \n2: No");
                Scanner continueOption = new Scanner(System.in);
                int optContinue = continueOption.nextInt();
                if (optContinue == 1) {
                    main(null);
                } else {
                    System.out.println("Thank you for using the App!");
                }
        }
    }
    private static void nairaToDollar() {//1
        System.out.println("Please enter the Naira amount to convert to Dollar");
        Scanner sc = new Scanner(System.in);
        double nairaAmount = sc.nextDouble();
        double dollarAmount = nairaAmount / 768;
        System.out.println("₦" + nairaAmount + " is $" + dollarAmount);

        System.out.println("********************************************");
        System.out.println("Please do you want to continue? \n1: Yes \n2: No");
        Scanner continueOption = new Scanner(System.in);
        int optContinue = continueOption.nextInt();
        if (optContinue == 1) {
            main(null);
        } else {
            System.out.println("Thank you for using the App!");
        }


    }

    private static void nairaToEuro() {//2
        Scanner sc = new Scanner(System.in);
        System.out.println("Please enter the Naira amount to convert to Euro");
        double nairaAmount = sc.nextDouble();
        double euroAmount = nairaAmount / 808;
        System.out.println("₦" + nairaAmount + " is €" + euroAmount);

        System.out.println("********************************************");
        System.out.println("Please do you want to continue? \n1: Yes \n2: No");
        Scanner continueOption = new Scanner(System.in);
        int optContinue = continueOption.nextInt();
        if (optContinue == 1) {
            main(null);
        } else {
            System.out.println("Thank you for using the App!");

        }
    }

    private static void nairaToPounds() {//3
        Scanner sc = new Scanner(System.in);
        System.out.println("Please enter the Naira amount to convert to Pounds");
        double nairaAmount = sc.nextDouble();
        double poundsAmount = nairaAmount / 808;
        System.out.println("₦" + nairaAmount + " is £" + poundsAmount);

        System.out.println("********************************************");
        System.out.println("Please do you want to continue? \n1: Yes \n2: No");
        Scanner continueOption = new Scanner(System.in);
        int optContinue = continueOption.nextInt();
        if (optContinue == 1) {
            main(null);
        } else {
            System.out.println("Thank you for using the App!");
        }
    }

    private static void euroToNaira() {//4
        Scanner sc = new Scanner(System.in);
        System.out.println("Please enter the Euro amount to convert to Naira");
        double euroAmount = sc.nextDouble();
        double nairaAmount = euroAmount * 826;
        System.out.println("£" + euroAmount + " is ₦" + nairaAmount);

        System.out.println("********************************************");
        System.out.println("Please do you want to continue? \n1: Yes \n2: No");
        Scanner continueOption = new Scanner(System.in);
        int optContinue = continueOption.nextInt();
        if (optContinue == 1) {
            main(null);
        } else {
            System.out.println("Thank you for using the App!");
        }
    }

    private static void poundsToNaira() {//5
        Scanner sc = new Scanner(System.in);
        System.out.println("Please enter Pounds amount to convert to Naira");
        double poundsAmount = sc.nextDouble();
        double nairaAmount = poundsAmount * 967;
        System.out.println("₦" + nairaAmount + " is £" + poundsAmount);

        System.out.println("********************************************");
        System.out.println("Please do you want to continue? \n1: Yes \n2: No");
        Scanner continueOption = new Scanner(System.in);
        int optContinue = continueOption.nextInt();
        if (optContinue == 1) {
            main(null);
        } else {
            System.out.println("Thank you for using the App!");
        }
    }

    private static void dollarToPounds() {//6
        Scanner sc = new Scanner(System.in);
        System.out.println("Please enter the Dollar amount to convert to Pounds");
        double dollarAmount = sc.nextDouble();
        double poundsAmount = dollarAmount / 1.2;
        System.out.println("$" + dollarAmount + " is £" + poundsAmount);

        System.out.println("********************************************");
        System.out.println("Please do you want to continue? \n1: Yes \n2: No");
        Scanner continueOption = new Scanner(System.in);
        int optContinue = continueOption.nextInt();
        if (optContinue == 1) {
            main(null);
        } else {
            System.out.println("Thank you for using the App!");
        }
    }

    private static void dollarToEuro() {//7
        Scanner sc = new Scanner(System.in);
        System.out.println("Please enter the Dollar amount to convert to Euro");
        double dollarAmount = sc.nextDouble();
        double euroAmount = dollarAmount / 808;
        System.out.println("$" + dollarAmount + " is £" + euroAmount);

        System.out.println("********************************************");
        System.out.println("Please do you want to continue? \n1: Yes \n2: No");
        Scanner continueOption = new Scanner(System.in);
        int optContinue = continueOption.nextInt();
        if (optContinue == 1) {
            main(null);
        } else {
            System.out.println("Thank you for using the App!");
        }
    }

    private static void poundsToDollar() {//8
        Scanner sc = new Scanner(System.in);
        System.out.println("Please enter the Pounds amount to convert to Dollar");
        double poundsAmount = sc.nextDouble();
        double dollarAmount = poundsAmount / 1.27;
        System.out.println("£" + poundsAmount + " is $" + dollarAmount);

        System.out.println("********************************************");
        System.out.println("Please do you want to continue? \n1: Yes \n2: No");
        Scanner continueOption = new Scanner(System.in);
        int optContinue = continueOption.nextInt();
        if (optContinue == 1) {
            main(null);
        } else {
            System.out.println("Thank you for using the App!");
        }
    }

    private static void poundsToEuro() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Please enter the Pounds amount to convert to Euro");
        double poundsAmount = sc.nextDouble();
        double euroAmount = poundsAmount * 1.17;
        System.out.println("£" + poundsAmount + " is €" + euroAmount);

        System.out.println("********************************************");
        System.out.println("Please do you want to continue? \n1: Yes \n2: No");
        Scanner continueOption = new Scanner(System.in);
        int optContinue = continueOption.nextInt();
        if (optContinue == 1) {
            main(null);
        } else {
            System.out.println("Thank you for using the App!");
        }
    }


    private static void euroToPounds() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Please enter the Euro amount to convert to Pounds");
        double euroAmount = sc.nextDouble();
        double poundsAmount = euroAmount / 0.86;
        System.out.println("€" + euroAmount + " is £" + poundsAmount);

        System.out.println("********************************************");
        System.out.println("Please do you want to continue? \n1: Yes \n2: No");
        Scanner continueOption = new Scanner(System.in);
        int optContinue = continueOption.nextInt();
        if (optContinue == 1) {
            main(null);
        } else {
            System.out.println("Thank you for using the App!");
        }
    }

    private static void euroToDollar() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Please enter the Euro amount to convert to Dollar");
        double euroAmount = sc.nextDouble();
        double dollarAmount = euroAmount * 1.09;
        System.out.println("€" + euroAmount + " is $" + dollarAmount);

        System.out.println("********************************************");
        System.out.println("Please do you want to continue? \n1: Yes \n2: No");
        Scanner continueOption = new Scanner(System.in);
        int optContinue = continueOption.nextInt();
        if (optContinue == 1) {
            main(null);
        } else {
            System.out.println("Thank you for using the App!");
        }
    }
}

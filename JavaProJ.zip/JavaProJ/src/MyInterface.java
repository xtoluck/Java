public interface MyInterface {
    void show();
    void config();
}

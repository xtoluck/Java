public class Arrays {
    public static void main(String[]args){

        String Animal[]=new String[7];
        String car []= {"Toyota","Peugeot","Ford","Lexus","Benz"};

        car[3]="Mazda";//updated the record of index 3 from Lexus to Mazda
        for (int i=0; i<car.length; i++) {
            System.out.println("The car at " +i+" is " +car[i]);
        }
    }
}

public class MultiDiemtionalArray {
    public static void main(String[] args) {
        int randomNumbers[][] = new int[3][4];//This means 3 rows and 4 columns. Normal array as the inner array size is fixed, 4.
        //int randomNumbers[][] = new int[3][];//This means 3 rows and n columns. Jagged array as the inner array size is unknown, n.
        System.out.println("%%%%%%% The 3 by 4 array is %%%%%%");


        for (int i = 0; i < 3; i++) {//i is for outer array
            for (int j = 0; j < 4; j++) {//j is for inner array
                randomNumbers[i][j] = (int) (Math.random() * 100); //generating random numbers and typecasting them from double to int after multiplying by 100;
                System.out.print(randomNumbers[i][j] + " "); //3 by 4 arrays. i.e. 3rows by 4columns.
            }
            System.out.println();


        } System.out.println("*********************");
        System.out.println("@@@@@ The random numbers are @@@@@");
        //To see the random numbers being generated
        for (int i=0;i<3;i++){
            for (int j=0;j<4;j++){
                System.out.println(randomNumbers[i][j]);
            }
        }
        System.out.println("=====================");
        System.out.println("***** The 3 by 4 array is *****");
        //Using enhanced for loop,
        for ( int eachArray[]:randomNumbers) {
            for(int eachArrayItems:eachArray){
                System.out.print(eachArrayItems+ " ");
            }
            System.out.println();
        }
    }
}

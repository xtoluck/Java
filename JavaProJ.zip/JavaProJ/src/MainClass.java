// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class MainClass implements MyInterface {

    @Override
    public void show() {
        System.out.println("in a show method of the MyInterface interface");
    }

    @Override
    public void config() {
        System.out.println("in config method of the MyInterface interface");
    }

    public static void main(String[] args) {
        // Press Alt+Enter with your caret at the highlighted text to see how
        // IntelliJ IDEA suggests fixing it.
        MainClass obj = new MainClass();
        obj.show();
        obj.config();

    }
}

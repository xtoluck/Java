public class MultiDimArray {
    public static void main(String[] args) {

        System.out.println("=====================");
         //2-D Array
        int [][] numbers=new int[3][5];
        for (int i=0; i<numbers.length;i++){
            for (int j=0;j<numbers.length;j++){
                numbers[i][j]=(int)(Math.random()*100);
                System.out.print(numbers[i][j]+" ");
            }
            System.out.println();
        }

    }
}

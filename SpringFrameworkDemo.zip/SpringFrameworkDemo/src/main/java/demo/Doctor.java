package demo;

public class Doctor {

    void assist(){
        System.out.println("Doctor can assist...");
    }
}

package demo;

public class Main {
    public static void main(String[] args) {
    Doctor doctor=new Doctor();
    doctor.assist();;
    }
}

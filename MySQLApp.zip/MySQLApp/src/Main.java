import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        try {
        Connection conn = DriverManager.getConnection("jdbc:mysql://xtodb:3306/", "root", "admin");
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT * FROM xtotable");
        while (rs.next()) {
            System.out.println(rs);
        }
    }
    catch (Exception e){
            e.printStackTrace();
    }
    }
}
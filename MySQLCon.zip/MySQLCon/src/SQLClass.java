import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class SQLClass {
    public static void main(String[] args) {
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/xtodb", "root", "admin");
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM xtotable");
            while (rs.next()) {
                System.out.println(+rs.getInt("id")+"\t"+rs.getString("fname")+"\t"+rs.getString("dept")+"\t"+rs.getString("age"));
            }
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }
}
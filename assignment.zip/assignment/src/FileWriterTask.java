import java.io.FileWriter;
import java.util.Scanner;

public class FileWriterTask {
    private static final int MIN_TEXT_LENGTH=20;
    private static final int MAX_TEXT_LENGTH=100;

    public static void main(String[] args) {
        System.out.println("Enter file name");
        Scanner fileNameScanner=new Scanner(System.in);
        String fileName=fileNameScanner.nextLine();

        try {
            FileWriter writer=new FileWriter(fileName);
            System.out.println("Enter text between " +MIN_TEXT_LENGTH + "and "+MAX_TEXT_LENGTH+"to write into the file"+fileName);
            String textFromUser = fileNameScanner.nextLine();
            if (textFromUser.length()< MIN_TEXT_LENGTH || textFromUser.length()>MAX_TEXT_LENGTH){
                throw new IllegalArgumentException ("The text length should be between "+MIN_TEXT_LENGTH+ "and "+MAX_TEXT_LENGTH);
            }else{
                writer.write(textFromUser);
                writer.close();
                System.out.println("Text successfully written to file!");
            }
        }
        catch (Exception e){


        }

    }
}

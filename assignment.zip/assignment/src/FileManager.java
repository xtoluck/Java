import java.io.*;
import java.util.Scanner;

public class FileManager {

    private static final int MIN_TEXT_LENGTH = 20;//declare the MIN length and instantiate
    private static final int MAX_TEXT_LENGTH = 100;//declare the MAX length and instantiate

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);//creates a scanner object
        FileManager.printOutput("Enter the file name: ");//call printOutput method and pass in the params "Enter the file name: "
        String fileName = scanner.nextLine();//assign the strings entered on the keyboard to fileName

        try {
            FileWriter writer = new FileWriter(fileName);//creates a FileWriter object
            FileManager.printOutput("Enter text to write (between " + MIN_TEXT_LENGTH + " and " + MAX_TEXT_LENGTH + " characters): ");//call printOutput method and pass in the params "Enter the file name:
            String text = scanner.nextLine();//assign the strings entered on the keyboard to variable, text

            if (text.length() < MIN_TEXT_LENGTH || text.length() > MAX_TEXT_LENGTH) {//if what's entered is < or > MIN and MAX,
                throw new IllegalArgumentException("Text length should be between " + MIN_TEXT_LENGTH + " and " + MAX_TEXT_LENGTH + " characters.");
            }

            writer.write(text);//write the text content into the file
            writer.close();//close the writer object
            FileManager.printOutput("Text written to file successfully!");//call the printOutput method and display the message, "Text written to file successfully!" passed.


            //Searching the file
            FileManager.printOutput("Enter the search text: ");//call the printOutput method and display the message, "Enter the search text:" passed.

            String searchText = scanner.nextLine();//assign the strings entered on the keyboard to variable, searchText

            FileReader reader = new FileReader(fileName);
            BufferedReader bufferedReader = new BufferedReader(reader);
            String line;
            int characterCount = 0;
            boolean found = false;

            while ((line = bufferedReader.readLine()) != null) {// while there is string on the line variable as bufferedReader.readLine() detects it
                if (line.contains(searchText)) {// the line var contains the string you want to search for
                    found = true;// the string is found
                    characterCount += line.length();
                    FileManager.printOutput("Matched text: " + line);//call the printOutput method and display the message, "Matched text:" passed.
                }
            }
            bufferedReader.close();// close the bufferReader
            reader.close();// close the reader
            FileManager.checkMatchedCharacters(found, characterCount);
        } catch (IOException e) {
            FileManager.printOutput("Error reading/writing file: " + e.getMessage());
        } catch (IllegalArgumentException e) {
            FileManager.printOutput("Invalid input: " + e.getMessage());
        } catch (Exception e) {
            FileManager.printOutput("An unexpected error occurred: " + e.getMessage());
        }
    }
    public static void checkMatchedCharacters(boolean found, int characterCount) {
        if (found) {
            FileManager.printOutput("Total characters matched: " + characterCount);
        } else {
            FileManager.printOutput("No match found.");
        }
    }
    public static void printOutput(String message) {//Everything about messages and prompt is handled by this method
        System.out.println(message);
    }
}
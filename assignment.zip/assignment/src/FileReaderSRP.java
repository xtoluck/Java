import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
public class FileReaderSRP {
    private static final int MIN_TEXT_LENGTH = 20;
    private static final int MAX_TEXT_LENGTH = 100;
    public void fileReaderSRP() throws IOException {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the file name: ");
        String fileName = scanner.nextLine();

        FileWriter writer = new FileWriter(fileName);
        System.out.print("Enter text to write (between " + MIN_TEXT_LENGTH + " and " + MAX_TEXT_LENGTH + " characters): ");
        String text = scanner.nextLine();

        System.out.print("Enter the search text: ");
        String searchText = scanner.nextLine();
        FileReader reader = new FileReader(fileName);
        BufferedReader bufferedReader = new BufferedReader(reader);
        String line;
        int characterCount = 0;
        boolean found = false;

        while ((line = bufferedReader.readLine()) != null) {
            if (line.contains(searchText)) {
                found = true;
                characterCount += line.length();
                System.out.println("Matched text: " + line);
            }
        }
        bufferedReader.close();
        reader.close();

        if (found) {
            System.out.println("Total characters matched: " + characterCount);
        } else {
            System.out.println("No match found.");
        }
    }

    public static void main(String[] args) throws IOException {
        FileReaderSRP fileReaderSRP=new FileReaderSRP();
        fileReaderSRP.fileReaderSRP();
    }
}
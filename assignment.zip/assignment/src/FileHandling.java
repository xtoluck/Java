import java.io.*;
import java.util.Scanner;

public class FileHandling {
    public static void main(String[] args) throws Exception {

        System.out.println("Please enter your input to be written to a file");//Prompts user for input string
        Scanner input = new Scanner(System.in);//Creates a Scanner object.
        String userInput = input.nextLine();//Takes the input string from user and stores it in userInput object

//enforcing the length of the input strings to be between 20 and 100 characters.
        if (userInput.length() >= 20 && userInput.length() <= 100) {

            File file = new File("myFile.txt");//Creates a new file
            FileOutputStream fos = new FileOutputStream(file);//Creates object of FileOutputStream and pass a filename to the newly created object
            DataOutputStream dos = new DataOutputStream(fos);//Creates object of DataOutputStream and pass the FileOutputStream obj content to the dos object
            //dos.writeUTF("Hello World... \nThis is a file handler project given to me by CodeAggressive!");//writes the data into the file fos object
            dos.writeUTF(userInput);// writes the input strings from user into the file.

            //To Read from the file
            FileInputStream fis = new FileInputStream(file); //creates an object of FileInputStream and passing file to it
            DataInputStream dis = new DataInputStream(fis);//creates an object of DataInputStream and passing fis to it
            String str = dis.readUTF();//reads the content of the file
            System.out.println("The content of the file, " + file + " is " + str);//prints the content of the file

            //Checking for existence of input string in a file
            System.out.println("Please enter string to check if it exists in the file, " + file);
            Scanner stringsToSearch = new Scanner(System.in);//Creates a Scanner object.
            String stringChecker = stringsToSearch.nextLine();//takes string input from user keyboard
            String string;
            FileReader fr = new FileReader(file);//creates a FileReader object and pass the file to it
            BufferedReader br = new BufferedReader(fr);//creates a BufferedReader object and pass fr to it
            while ((string = br.readLine()) != null) {
                if (string.contains(stringChecker)) {
                    System.out.print("The string " + string + " is found!\n");
                } else {
                    System.out.println("Strings NOT found!");

                    System.out.println("******");
                    System.out.println("Please do you want to continue? \n1: Yes \n2: No");
                    Scanner continueOption = new Scanner(System.in);
                    int optContinue = continueOption.nextInt();
                    if (optContinue == 1) {
                        main(null);
                    } else {
                        System.out.println("Thank you for using the App!");
                    }
                }
            }
        } else {
            System.out.println("oops...! The length of your input string is outside the allowable range! 20 to 100 characters!");
            System.out.println("******");
            System.out.println("Please do you want to continue? \n1: Yes \n2: No");
            Scanner continueOption = new Scanner(System.in);
            int optContinue = continueOption.nextInt();
            if (optContinue == 1) {
                main(null);
            } else {
                System.out.println("Thank you for using the App!");
            }
        }
    }
}
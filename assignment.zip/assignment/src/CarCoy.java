import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class CarCoy {
    public void carFord() {
        Map<String, HashMap<String, Integer>> multiValueMap = new HashMap<>();
        multiValueMap.put("Ford", new HashMap<>());
        multiValueMap.get("Ford").put("Green", 2000);
        multiValueMap.get("Ford").put("Black", 2500);
        multiValueMap.get("Ford").put("Blue", 4300);
        System.out.println("The available brand specs are: ");
        System.out.println(multiValueMap.get("Ford"));


        System.out.println("Please select your brand colour? \n1 => GREEN\n2 => BLACK\n3 => BLUE\n");
        Scanner option = new Scanner(System.in);
        int opt = option.nextInt();
        if (opt == 1) {
            carFordGreen();
        } else if (opt == 2) {
            carFordBlack();
        } else if (opt == 3) {
            carFordBlue();
        } else System.out.println("Invalid Option!");
    }
    private void carFordGreen() {
        Map<String, ArrayList<String>> carFordGreenmultiValueMap = new HashMap<>();
        carFordGreenmultiValueMap.put("Ford", new ArrayList<>());
        carFordGreenmultiValueMap.get("Ford").add("Green, $2000, 2016 Model, German made");
        System.out.println(carFordGreenmultiValueMap.get("Ford"));
    }

    private void carFordBlack() {
        Map<String, ArrayList<String>> carFordGreenmultiValueMap = new HashMap<>();
        carFordGreenmultiValueMap.put("Ford", new ArrayList<>());
        carFordGreenmultiValueMap.get("Ford").add("Black, $2100, 2017 Model, UK made");
        System.out.println(carFordGreenmultiValueMap.get("Ford"));
    }

    private void carFordBlue() {
        Map<String, ArrayList<String>> carFordGreenmultiValueMap = new HashMap<>();
        carFordGreenmultiValueMap.put("Ford", new ArrayList<>());
        carFordGreenmultiValueMap.get("Ford").add("Blue, $3500, 2018 Model, American made");
        System.out.println(carFordGreenmultiValueMap.get("Ford"));
    }
    public void carToyota() {
        Map<String, HashMap<String, Integer>> multiValueMap = new HashMap<>();

        multiValueMap.put("Toyota", new HashMap<>());
        multiValueMap.get("Toyota").put("Green", 2000);
        multiValueMap.get("Toyota").put("Black", 2500);
        multiValueMap.get("Toyota").put("Red", 4300);
        System.out.println("The available brand specs are: ");
        System.out.println(multiValueMap.get("Toyota"));

        System.out.println("Please select your brand colour? \n1 => GREEN\n2 => BLACK\n3 => BLUE\n");
        Scanner option = new Scanner(System.in);
        int opt = option.nextInt();
        if (opt == 1) {
            carToyotaGreen();
        } else if (opt == 2) {
            carToyotaBlack();
        } else if (opt == 3) {
            carToyotaBlue();
        } else System.out.println("Invalid Option!");
    }
    private void carToyotaGreen() {
        Map<String, ArrayList<String>> carFordGreenmultiValueMap = new HashMap<>();
        System.out.println("The full details are:");
        carFordGreenmultiValueMap.put("Toyota", new ArrayList<>());
        carFordGreenmultiValueMap.get("Toyota").add("Green, $900, 2001 Model, German made");
        System.out.println(carFordGreenmultiValueMap.get("Toyota"));
    }
    private void carToyotaBlack() {
        Map<String, ArrayList<String>> carFordGreenmultiValueMap = new HashMap<>();
        System.out.println("The full details are:");
        carFordGreenmultiValueMap.put("Toyota", new ArrayList<>());
        carFordGreenmultiValueMap.get("Toyota").add("Black, $800, 2012 Model, UK made");
        System.out.println(carFordGreenmultiValueMap.get("Toyota"));
    }
    private void carToyotaBlue() {
        Map<String, ArrayList<String>> carFordGreenmultiValueMap = new HashMap<>();
        carFordGreenmultiValueMap.put("Toyota", new ArrayList<>());
        System.out.println("The full details are:");
        carFordGreenmultiValueMap.get("Toyota").add("Blue, $3500, 2018 Model, American made");
        System.out.println(carFordGreenmultiValueMap.get("Toyota"));
    }
    public void carBenz() {
        Map<String, HashMap<String, Integer>> multiValueMap = new HashMap<>();

        multiValueMap.put("Benz", new HashMap<>());
        multiValueMap.get("Benz").put("Green", 2000);
        multiValueMap.get("Benz").put("Black", 2500);
        multiValueMap.get("Benz").put("White", 4300);
        System.out.println("The available brand specs are: ");
        System.out.println(multiValueMap.get("Benz"));

        System.out.println("Please select your brand colour? \n1 => GREEN\n2 => BLACK\n3 => BLUE\n");
        Scanner option = new Scanner(System.in);
        int opt = option.nextInt();
        if (opt == 1) {
            carBenzGreen();
        } else if (opt == 2) {
            carBenzBlack();
        } else if (opt == 3) {
            carBenzBlue();
        } else System.out.println("Invalid Option!");
    }

    private void carBenzBlue() {
        Map<String, ArrayList<String>> carFordGreenmultiValueMap = new HashMap<>();
        carFordGreenmultiValueMap.put("Benz", new ArrayList<>());
        System.out.println("The full details are:");
        carFordGreenmultiValueMap.get("Toyota").add("Blue, $3500, 2018 Model, American made");
        System.out.println(carFordGreenmultiValueMap.get("Benz"));
    }
    private void carBenzGreen() {
        Map<String, ArrayList<String>> carFordGreenmultiValueMap = new HashMap<>();
        carFordGreenmultiValueMap.put("Benz", new ArrayList<>());
        System.out.println("The full details are:");
        carFordGreenmultiValueMap.get("Benz").add("Green, $3500, 2018 Model, American made");
        System.out.println(carFordGreenmultiValueMap.get("Benz"));
    }
    private void carBenzBlack() {
        Map<String, ArrayList<String>> carFordGreenmultiValueMap = new HashMap<>();
        carFordGreenmultiValueMap.put("Benz", new ArrayList<>());
        System.out.println("The full details are:");
        carFordGreenmultiValueMap.get("Benz").add("Black, $3500, 2018 Model, American made");
        System.out.println(carFordGreenmultiValueMap.get("Benz"));
    }
    void purchaseCar() {
        System.out.println("Do you want to buy car? \n1 => YES\n2 => NO\n");
        Scanner option = new Scanner(System.in);
        int opt = option.nextInt();
        if (opt == 1) {
            System.out.print("Available brands are: \n1 => Ford\n" +
                             "2 => Toyota\n" +
                             "3 => Benz");
            opt = option.nextInt();
            if (opt == 1) {
                carFord();
            } else if (opt == 2) {
                carToyota();
            } else if (opt == 3) {
                carBenz();
            } else System.out.println("Invalid Option!");
        }
    }
    public static void main(String[] args) {
        CarCoy car = new CarCoy();
        car.purchaseCar();
    }
}
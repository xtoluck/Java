public class MyMainMethodClass {
    public static void main(String[] args) {
/*        System.out.println("Hello \nLucky Christopher");

        MyJavaAppClass sumTwoNumbersObj = new MyJavaAppClass();
        sumTwoNumbersObj.sumTwoNumbers();

        MyJavaAppClass divideTwoNumbersObj = new MyJavaAppClass();
        divideTwoNumbersObj.divideTwoNumbers();

        MyJavaAppClass mathOpsObj = new MyJavaAppClass();
        mathOpsObj.mathOps();

        MyJavaAppClass scannerInputFromUserObj = new MyJavaAppClass();
        scannerInputFromUserObj.scannerInputFromUser();

        MyJavaAppClass americaFlagObj = new MyJavaAppClass();
        americaFlagObj.americaFlagPattern();


        MyJavaAppClass swapTwoVariablesObj= new MyJavaAppClass();
        swapTwoVariablesObj.swapTwoVariables();

        MyJavaAppClass addBinaryObj = new MyJavaAppClass();
        addBinaryObj.addBinary();


        MyJavaAppClass quadraticEquationObj = new MyJavaAppClass();
        quadraticEquationObj.quadraticEquation();

        MyJavaAppClass.add(1,3,4);
        MyJavaAppClass.add(9,2);

 */

        //MyJavaAppClass.finalDemo();//This method, finalDemo() was called this way because it was declared static in the class
        MyJavaAppClass constructorClassObj =new MyJavaAppClass("","",0);

    }
}


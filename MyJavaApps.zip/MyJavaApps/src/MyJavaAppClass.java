
import java.util.Scanner;
import java.util.logging.SocketHandler;

public class MyJavaAppClass {
/*
        void sumTwoNumbers() {
            int firstNumber = 74;
            int secondNumber = 36;
            int result = firstNumber + secondNumber;
            System.out.println("The sum of the given two test data is " + result);
        }

        void divideTwoNumbers() {
            int firstNumber = 50;
            int secondNumber = 3;
            int result = firstNumber / secondNumber;
            System.out.println("The Division of the two test data is " + result);

        }

        void mathOps() {
            int a = -5 + 8 * 6;
            System.out.println("A. " + a);

            int b = (55 + 9) % 9;
            System.out.println("B. " + b);

            int c = 20 + -3 * 5 / 8;
            System.out.println("C. " + c);

            int d = 5 + 15 / 3 * 2 - 8 % 3;
            System.out.println("D. " + d);
        }

        void scannerInputFromUser() {
            Scanner inputObj = new Scanner(System.in);
            System.out.println("Input first number: ");
            int firstNumber = inputObj.nextInt();

            System.out.println("Input second number: ");
            int secondNumber = inputObj.nextInt();

            int resultSet = firstNumber * secondNumber;

            System.out.printf("The Result of First and SecondNumber is: " + resultSet);
        }

        void multiplicationTable() {
            Scanner multObj = new Scanner(System.in);
            System.out.println("Please input the number to Multiply: ");
            int numberToMultiply = multObj.nextInt();

            // for (int i = 0; i < ; i++) {

            //  }
        }

        void americaFlagPattern() {
            System.out.println("* * * * * * ==================================");
            System.out.println(" * * * * *  ==================================");
            System.out.println("* * * * * * ==================================");
            System.out.println(" * * * * *  ==================================");
            System.out.println("* * * * * * ==================================");
            System.out.println(" * * * * *  ==================================");
            System.out.println("* * * * * * ==================================");
            System.out.println(" * * * * *  ==================================");
            System.out.println("* * * * * * ==================================");
            System.out.println("==============================================");
            System.out.println("==============================================");
            System.out.println("==============================================");
            System.out.println("==============================================");
            System.out.println("==============================================");
            System.out.println("==============================================");

        }

        void swapTwoVariables() {
            System.out.println("Please input First Variable");
            Scanner input1 = new Scanner(System.in);
            int var1 = input1.nextInt();
            System.out.println("Please input Second Variable");
            Scanner input2 = new Scanner(System.in);
            int var2 = input2.nextInt();
            System.out.println("Before Swap Variable1 is "+var1+" and Variable2 is "+var2);

            //swapping process
            int temp = var1;
            var1 = var2;
            var2 = temp;

            System.out.println("After Swap Variable1 is "+var1+" and Variable2 is "+var2);


        }


        void addBinary() {
            long binary1, binary2;
            int i = 0, remainder = 0;

            int[] sum = new int[20];

            Scanner in = new Scanner(System.in);
            System.out.println("Please enter the first Binary Numbers");
            binary1 = in.nextLong();

            System.out.printf("Please enter the second Binary Numbers");
            binary2 = in.nextLong();

            while (binary1 != 0 || binary2 != 0) {

                sum[i++] = (int) ((binary1 % 10 + binary2 % 10 + remainder) % 2);
                remainder = (int) ((binary1 % 10 + binary2 % 10 + remainder) / 2);
                binary1 = binary1 / 10;
                binary2 = binary2 / 10;
            }
            if (remainder != 0) {
                sum[i++] = remainder;
            }
            --i;
            System.out.println("Sum of two Binary Numbers: ");
            while (i >= 0) {
                System.out.print(sum[i--]);
            }
            System.out.println("\n");
        }


    void quadraticEquation() {


        //x=-b+- sqrt ((b*b)-4*a*c))/2*a

        double a, b, c, y1, y2, y3, x1, x2;

        Scanner input = new Scanner(System.in);
        System.out.printf("Please enter the value of A: \n");
        a = input.nextDouble();

        System.out.printf("Please enter the value of B: \n");
        b = input.nextDouble();

        System.out.printf("Please enter the value of C: \n");
        c = input.nextDouble();

        y1 = ((b * b) - (4 * a * c));
        y2 = (2 * a);
        y3 = Math.sqrt(y1);


        try {
            if (y1 < 0) {
                System.out.println("Negative Square root NOT ALLOWED! Ensure the value of B is greater than the values of A and C");
            } else {

                x1 = (-b + y3) / y2;
                x2 = -(-b + y3) / y2;

                System.out.println("The value for X1 is " + x1);
                System.out.println("The value for X1 is " + x2);
                System.out.println("The value for A, B and C is \n" + "A: " + a + "\nB: " + b + "\nC: " + c);
            }
        } catch (Exception e) {
            System.out.println(" Hey! You entered wrong inputs()");
        }

    }

    static double add( double a, double b, double c){//This is method overloading.
        Scanner inp=new Scanner(System.in);

        System.out.println("Please input A: \n");
        a=inp.nextDouble();
        System.out.println("Please input B: \n");
        b=inp.nextDouble();
        System.out.println("Please input C: \n");
        c=inp.nextDouble();



        double result=a+b+c;
        System.out.println("The result of the addition of three numbers is "+result);
        return result;

    }

    static double add( double a, double b){// This is method overloading.
        Scanner inp=new Scanner(System.in);

        System.out.println("Please input A: \n");
        a=inp.nextDouble();
        System.out.println("Please input B: \n");
        b=inp.nextDouble();
        System.out.println("Please input C: \n");
        c=inp.nextDouble();

        double result=a+b;
        System.out.println("The result of the addition of two numbers is "+result);
        return result;
    }



    int aaa = 6;

    static int finalDemo() {
        MyJavaAppClass obj1 = new MyJavaAppClass();
        MyJavaAppClass obj2 = new MyJavaAppClass();
        obj1.aaa = 3;
        System.out.println("The value of a RE-ASSIGNED is : " + obj1.aaa);
        System.out.println("The value of a ORIGINAL is : " + obj2.aaa);

        return 0;// this return stmt is because the mtd was declared with a data type, int and not void.
    }

 */

    MyJavaAppClass(String firstName, String lastName, int age) { //This is a constructor with 3 params

        Scanner input = new Scanner(System.in);
        System.out.println("Please enter age");
        age = input.nextInt();

        System.out.println("Please enter your First name: ");
        firstName = input.next();

        System.out.println("Please enter your Last name: ");
        lastName = input.next();

        String constructorOutput = firstName.concat(" " +lastName) + ("    " + age);
        System.out.println("FULL NAME            AGE");
        System.out.println("************************");
        System.out.println(constructorOutput);
        System.out.println("========================");

    }

}
